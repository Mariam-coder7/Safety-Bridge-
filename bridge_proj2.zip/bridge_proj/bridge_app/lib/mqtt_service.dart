// lib/mqtt_service.dart
import 'package:flutter/material.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';


class MqttService {
  late MqttServerClient client;

  // Store values
  static Map<String, String> sensorValues = {
    'vibration': '',
    'water': '',
    'alerts': '',
    'gate1_status': '',
    'gate2_status': '',
  };

  Future<void> connect() async {
    client = MqttServerClient(
      'YOUR_BROKER_URL', // fill in
      'flutter_dashboard_${DateTime.now().millisecondsSinceEpoch}',
    );

    client.port = 8883;
    client.secure = true;
    client.logging(on: false);

    client.onConnected = () => debugPrint('✅ MQTT Connected');
    client.onDisconnected = () => debugPrint('❌ MQTT Disconnected');

    final connMess = MqttConnectMessage()
        .withClientIdentifier(
            'flutter_dashboard_${DateTime.now().millisecondsSinceEpoch}')
        .startClean();
    client.connectionMessage = connMess;

    try {
      await client.connect(
        'YOUR_USERNAME', // fill in
        'YOUR_PASSWORD', // fill in
      );
    } catch (e) {
      debugPrint('MQTT connect failed: $e');
      try {
        client.disconnect();
      } catch (_) {}
      return;
    }

    if (client.connectionStatus?.state == MqttConnectionState.connected) {
      _subscribeToTopics();
    }
  }

  void _subscribeToTopics() {
    client.subscribe("bridge/sensor/vibration", MqttQos.atMostOnce);
    client.subscribe("bridge/sensor/water", MqttQos.atMostOnce);
    client.subscribe("bridge/alerts", MqttQos.atMostOnce);
    client.subscribe("bridge/gates/gate1/status", MqttQos.atMostOnce);
    client.subscribe("bridge/gates/gate2/status", MqttQos.atMostOnce);

    client.updates!.listen((List<MqttReceivedMessage<MqttMessage>> c) {
      final recMsg = c[0].payload as MqttPublishMessage;
      final payload =
          MqttPublishPayload.bytesToStringAsString(recMsg.payload.message).trim();
      final topic = c[0].topic;

      debugPrint("📩 [$topic] $payload");

      switch (topic) {
        case "bridge/sensor/vibration":
          sensorValues['vibration'] = payload;
          break;
        case "bridge/sensor/water":
          sensorValues['water'] = payload;
          break;
        case "bridge/alerts":
          sensorValues['alerts'] = payload;
          break;
        case "bridge/gates/gate1/status":
          sensorValues['gate1_status'] = payload;
          break;
        case "bridge/gates/gate2/status":
          sensorValues['gate2_status'] = payload;
          break;
      }
    });
  }

  // Optional: publish gate commands
  void publishGate1(String command) {
    final builder = MqttClientPayloadBuilder();
    builder.addString(command);
    client.publishMessage("bridge/gates/gate1/cmd", MqttQos.atMostOnce, builder.payload!);
  }

  void publishGate2(String command) {
    final builder = MqttClientPayloadBuilder();
    builder.addString(command);
    client.publishMessage("bridge/gates/gate2/cmd", MqttQos.atMostOnce, builder.payload!);
  }
}
