import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'mqtt_service.dart';  
late MqttService mqttService;
// ---------------- GLOBAL BRIDGE STATUS ----------------
class BridgeStatus {
  static bool bridgeSafe = true;       // is bridge safe overall
  static bool gateOpen = true;         // are gates open
  static bool earthquakeSafe = true;   // is earthquake level safe
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://fvlptjzaleesanbusaoi.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ2bHB0anphbGVlc2FuYnVzYW9pIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY0NzM0MzQsImV4cCI6MjA3MjA0OTQzNH0.d3XDPnlOiiDnr3v2IHiy5QBpKKauKP5HNcRVWmjyKtw',
  );
  
  mqttService = MqttService();
  await mqttService.connect();
  runApp(const MyApp());
} 

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const LoginPage(),
    );
  }
}

// ---------------- HISTORY PAGE ----------------

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  int selectedCategory = 0; // 0 = Cars, 1 = Earthquake, 2 = Water
  int selectedNavIndex = 1; // History is selected

  void _navigateToPage(int index) {
    if (index == 0) { // Home tab
      Navigator.pop(context); // Go back to home
    } else {
      setState(() {
        selectedNavIndex = index;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFB3E5FC),
      body: SafeArea(
        child: Column(
          children: [
            // Top Navigation Bar
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  const Icon(Icons.account_balance, color: Colors.teal, size: 32),
                  const Spacer(),
                  _buildNavButton("Home", 0),
                  _buildNavButton("History", 1),
                  _buildNavButton("Alert", 2),
                  _buildNavButton("Setting", 3),
                ],
              ),
            ),
            
            // History Header
            Container(
              padding: const EdgeInsets.all(16),
              alignment: Alignment.centerLeft,
              child: const Text(
                "history",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
            ),

            // Category Buttons
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  _buildCategoryButton("Cars", 0),
                  const SizedBox(width: 8),
                  _buildCategoryButton("Earthquake", 1),
                  const SizedBox(width: 8),
                  _buildCategoryButton("Water", 2),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Content Area
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: _buildCategoryContent(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _updateBridgeSafety() {
    // Bridge is safe if gates are open and earthquake level is low
    BridgeStatus.bridgeSafe = BridgeStatus.gateOpen && BridgeStatus.earthquakeSafe;
  }

  Widget _buildNavButton(String text, int index) {
    bool isSelected = selectedNavIndex == index;
    return GestureDetector(
      onTap: () => _navigateToPage(index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? Colors.teal.shade200 : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.black87,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryButton(String text, int index) {
    bool isSelected = selectedCategory == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedCategory = index;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? Colors.teal.shade400 : Colors.teal.shade200,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: Colors.white,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryContent() {
    switch (selectedCategory) {
      case 0: // Cars
        return _buildCarsContent();
      case 1: // Earthquake
        return _buildEarthquakeContent();
      case 2: // Water
        return _buildWaterContent();
      default:
        return Container();
    }
  }

  Widget _buildCarsContent() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Cars",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          _buildHistoryItem("🚗 Cars: 450 →", "Today · 3:00 PM"),
          _buildHistoryItem("🚗 Cars: 350 →", "Today · 5:00 PM"),
          _buildHistoryItem("🚗 Cars: 200 →", "yesterday · 7:00 PM"),
        ],
      ),
    );
  }

  Widget _buildWaterContent() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Water",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          _buildHistoryItem("🌊 Water: 3m →", "Today · 3:00 PM"),
          _buildHistoryItem("🌊 Water: 4m →", "Today · 5:00 PM"),
          _buildHistoryItem("🌊 Water: 6m →", "yesterday · 7:00 PM"),
        ],
      ),
    );
  }

  Widget _buildEarthquakeContent() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Quake",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 16),
          _buildHistoryItem("🌍 Quake: 2.5 →", "Today · 3:00 PM"),
          _buildHistoryItem("🌍 Quake: 3 →", "Today · 5:00 PM"),
          _buildHistoryItem("🌍 Quake: 3 →", "yesterday · 7:00 PM"),
        ],
      ),
    );
  }

  Widget _buildHistoryItem(String title, String time) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            time,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------- LOGIN PAGE ----------------

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool showGovLogin = false;

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passController = TextEditingController();

  void _continueAsUser() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const UserHomePage()),
    );
  }

  Future<void> _loginAsGov() async {
    final email = emailController.text.trim();
    final password = passController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter email & password")),
      );
      return;
    }

    try {
  final response = await Supabase.instance.client.auth
      .signInWithPassword(email: email, password: password);

  if (response.user != null) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const GovHomePage()),
    );
  }
} on AuthException catch (_) {
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Text("Invalid login. Please register first.")),
  );
} catch (e) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text("Error: $e")),
  );
}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFB3E5FC),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // Register button
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const RegisterPage(),
                        ),
                      );
                    },
                    style: TextButton.styleFrom(
                      backgroundColor: Colors.black26,
                      foregroundColor: Colors.white,
                    ),
                    child: const Text("Register"),
                  ),
                ],
              ),

              const Spacer(),

              // Logo
              Center(
                child: Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    color: Colors.blue.shade200,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(
                    Icons.account_balance,
                    size: 60,
                    color: Colors.blueGrey,
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // Continue as User
              ElevatedButton(
                onPressed: _continueAsUser,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueGrey,
                  minimumSize: const Size(220, 45),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text("Continue as user"),
              ),

              const SizedBox(height: 12),

              // Government Login
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    showGovLogin = true;
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueGrey,
                  minimumSize: const Size(220, 45),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text("Government Login"),
              ),

              const SizedBox(height: 20),

              if (showGovLogin) ...[
                TextField(
                  controller: emailController,
                  decoration: InputDecoration(
                    labelText: "Email",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: passController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: "Password",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: _loginAsGov,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    minimumSize: const Size(220, 45),
                  ),
                  child: const Text("Login"),
                ),
              ],

              const Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------- REGISTER PAGE ----------------

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final usernameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final passwordController = TextEditingController();

  Future<void> _register() async {
  final email = emailController.text.trim();
  final password = passwordController.text.trim();
  final username = usernameController.text.trim();
  final phone = phoneController.text.trim();

  if (email.isEmpty || password.isEmpty || username.isEmpty || phone.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Please fill all required fields")),
    );
    return;
  }

  try {
    // Create auth account
    final authResponse = await Supabase.instance.client.auth
        .signUp(email: email, password: password);

    final user = authResponse.user;
    if (user != null) {
      // Instead of insert → update (with matching user.id)
      await Supabase.instance.client
    .from("profiles")
    .upsert({
      'id': user.id,      // make sure to include id
      'username': username,
      'phone': phone,
    });


      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Registration successful! Please login.")),
      );
      Navigator.pop(context);
    }
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Error: $e")),
    );
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFB3E5FC),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            children: [
              const SizedBox(height: 40),
              Center(
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: Colors.blue.shade200,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(
                    Icons.account_balance,
                    size: 50,
                    color: Colors.blueGrey,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Register",
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              TextField(
                controller: usernameController,
                decoration: InputDecoration(
                  labelText: "Username",
                  hintText: "Enter your username",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              const SizedBox(height: 12),

              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: "Email",
                  hintText: "Enter your email",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              const SizedBox(height: 12),

              TextField(
                controller: phoneController,
                decoration: InputDecoration(
                  labelText: "Phone number",
                  hintText: "Enter your number",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              const SizedBox(height: 12),

              TextField(
                controller: passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: "Password",
                  hintText: "Create strong password",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              ElevatedButton(
                onPressed: _register,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueGrey,
                  minimumSize: const Size(220, 45),
                ),
                child: const Text("Register"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


// ---------------- HOME PAGES ----------------

class UserHomePage extends StatefulWidget {
  const UserHomePage({super.key});

  @override
  State<UserHomePage> createState() => _UserHomePageState();
}

class _UserHomePageState extends State<UserHomePage> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFB3E5FC),
      body: SafeArea(
        child: Column(
          children: [
            // Top Navigation Bar
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  const Icon(Icons.account_balance, color: Colors.teal, size: 32),
                  const Spacer(),
                  _buildNavButton("Home", 0),
                  _buildNavButton("History", 1),
                  _buildNavButton("Alert", 2),
                  _buildNavButton("Setting", 3),
                ],
              ),
            ),
            
            // User Header
            Container(
              padding: const EdgeInsets.all(16),
              alignment: Alignment.centerLeft,
              child: const Text(
                "user",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Bridge Safety Status Title
            const Text(
              "bridge safety status",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
            ),

            const SizedBox(height: 30),

            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    // Bridge and Gates Status
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          children: [
                            const Text(
                              "bridge",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 12),
                            _buildStatusButton(
                              BridgeStatus.bridgeSafe ? "safe" : "Not safe",
                              BridgeStatus.bridgeSafe,
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            const Text(
                              "Gates",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 12),
                            _buildStatusButton(
                              BridgeStatus.gateOpen ? "open" : "Closed",
                              BridgeStatus.gateOpen,
                            ),
                          ],
                        ),
                      ],
                    ),

                    const SizedBox(height: 40),

                    // Earthquake Prediction
                    const Text(
                      "earthquake prediction",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),

                    const SizedBox(height: 20),

                    _buildStatusButton(
                      BridgeStatus.earthquakeSafe ? "safe" : "warning",
                      BridgeStatus.earthquakeSafe,
                    ),

                    const Spacer(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavButton(String text, int index) {
    bool isSelected = selectedIndex == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedIndex = index;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? Colors.teal.shade200 : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.black87,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildStatusButton(String text, bool isPositive) {
    return Container(
      width: 120,
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: isPositive ? Colors.green.shade400 : Colors.red.shade400,
        borderRadius: BorderRadius.circular(25),
      ),
      child: Center(
        child: Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

class GovHomePage extends StatefulWidget {
  const GovHomePage({super.key});

  @override
  State<GovHomePage> createState() => _GovHomePageState();
}

class _GovHomePageState extends State<GovHomePage> {

void _updateBridgeSafety() {
  // Bridge is safe only if gates are open AND earthquake is safe
  setState(() {
    BridgeStatus.bridgeSafe =
        BridgeStatus.gateOpen && BridgeStatus.earthquakeSafe;
  });
}

  int selectedIndex = 0;
  bool gateStatus = true; // true = open, false = closed
  double earthquakeLevel = 0.3;
  
  // Sample water level data
  List<double> waterLevels = [80, 60, 70, 65, 85, 75, 90, 85, 95, 80];

  void _navigateToPage(int index) {
    if (index == 1) { // History tab
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const HistoryPage()),
      );
    } else {
      setState(() {
        selectedIndex = index;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFB3E5FC),
      body: SafeArea(
        child: Column(
          children: [
            // Top Navigation Bar
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  const Icon(Icons.account_balance, color: Colors.teal, size: 32),
                  const Spacer(),
                  _buildNavButton("Home", 0),
                  _buildNavButton("History", 1),
                  _buildNavButton("Alert", 2),
                  _buildNavButton("Setting", 3),
                ],
              ),
            ),
            
            // GOV Header
            Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Text(
                    "GOV",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.teal.shade300,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      "Control panel",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Control Gates Section
                    Row(
                      children: [
                        const Text(
                          "Control gates:",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(width: 16),
                        _buildGateButton("open", true),
                        const SizedBox(width: 8),
                        _buildGateButton("Close", false),
                      ],
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Water Level Section
                    const Text(
                      "Water level:",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Water Level Chart
                    Container(
                      height: 200,
                      child: _buildWaterLevelChart(),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Earthquake Level Section
                    const Text(
                      "Earthquake level:",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Earthquake Level Slider
                    Container(
                      height: 60,
                      child: SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          activeTrackColor: Colors.blue.shade700,
                          inactiveTrackColor: Colors.grey.shade300,
                          thumbColor: Colors.white,
                          overlayColor: Colors.blue.withAlpha(32),
                          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 12),
                          trackHeight: 8,
                        ),
                        child: Slider(
                          value: earthquakeLevel,
                          min: 0,
                          max: 1,
                          onChanged: (value) {
                            setState(() {
                              earthquakeLevel = value;
                              // Update earthquake safety based on level
                              BridgeStatus.earthquakeSafe = value < 0.5;
                              _updateBridgeSafety();
                            });
                          },
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Reports Section
                    Row(
                      children: [
                        const Text(
                          "Reports:",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(width: 16),
                        const Text(
                          "move to →",
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.black54,
                          ),
                        ),
                        const SizedBox(width: 8),
                        ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const HistoryPage()),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal.shade400,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          ),
                          child: const Text(
                            "history",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavButton(String text, int index) {
    bool isSelected = selectedIndex == index;
    return GestureDetector(
      onTap: () => _navigateToPage(index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF80CBC4) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.black87,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildGateButton(String text, bool isOpen) {
  bool isSelected = gateStatus == isOpen;
  Color buttonColor = isOpen ? Colors.green : Colors.red;

  return GestureDetector(
    onTap: () {
      setState(() {
        gateStatus = isOpen;
        BridgeStatus.gateOpen = isOpen;
        _updateBridgeSafety();

        // 🟢 Send MQTT command
        if (isOpen) {
          mqttService.publishGate1("open");
          mqttService.publishGate2("open");
        } else {
          mqttService.publishGate1("close");
          mqttService.publishGate2("close");
        }
      });
    },
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: isSelected ? buttonColor : Colors.grey.shade300,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.black54,
          fontWeight: FontWeight.w500,
        ),
      ),
    ),
  );
}


  Widget _buildWaterLevelChart() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.3),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          // Y-axis labels
          Row(
            children: [
              SizedBox(
                width: 30,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text("3m", style: TextStyle(fontSize: 12)),
                    Text("2m", style: TextStyle(fontSize: 12)),
                    Text("1m", style: TextStyle(fontSize: 12)),
                    Text("0.5m", style: TextStyle(fontSize: 12)),
                    Text("0", style: TextStyle(fontSize: 12)),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  height: 120,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: waterLevels.map((level) {
                      return Container(
                        width: 20,
                        height: level * 1.2, // Scale the height
                        decoration: BoxDecoration(
                          color: Colors.blue.shade600,
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          // X-axis labels
          Padding(
            padding: const EdgeInsets.only(left: 30),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(10, (index) {
                return Text(
                  "$index",
                  style: const TextStyle(fontSize: 12),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}